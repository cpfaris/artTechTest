//
//  RegisterModel.swift
//  ArtTechTest
//
//  Created by Faris on 18/07/23.
//

import Foundation


class register{
    var userName : String?
    var password : String?
    
    init(userName: String? = nil, password: String? = nil) {
        self.userName = userName
        self.password = password
    }
}
