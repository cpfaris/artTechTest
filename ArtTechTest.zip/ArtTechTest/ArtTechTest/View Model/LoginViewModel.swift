//
//  LoginViewModel.swift
//  ArtTechTest
//
//  Created by Faris on 18/07/23.
//

import Foundation
import CoreData
import UIKit
class loginViewModel{
    var delegate: LoginViewModelDelegate?
    var context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    var userName : String?
    var password : String?
    
    func fieldValidation(){
        if (userName == nil) || (userName == ""){
            self.delegate?.showError("Login","Please enter a valid username  ")
        }
        else if (password == nil) || (password == "") {
            self.delegate?.showError("Login","Please enter a valid password  ")
        }else{
            coreDataLogin(userName: userName ?? "", password: password ?? "")
        }
        
    }
    func coreDataLogin(userName:String, password:String){
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Users")
        let searchString = userName
        let searcghstring2 = password
        request.predicate = NSPredicate (format: "username == %@", searchString)
        do
        {
            let result = try context.fetch(request)
            if result.count > 0
            {
                let   n = (result[0] as AnyObject).value(forKey: "username") as! String
                let p = (result[0] as AnyObject).value(forKey: "password") as! String
                //  print(" checking")
                
                
                if (searchString == n && searcghstring2 == p)
                {
                    
                    delegate?.loginCompletion(userName: n)
                    
                }
                else if (searchString == n || searcghstring2 == p)
                {
                    self.delegate?.showError("No user found", "Password incorrect ")
                    print("password incorrect ")
                    
                }
            }
            else
            { self.delegate?.showError("No user found", "Invalid username ")
                
                
            }
        }
        catch
        {
            print("error")
        }
    }
}
