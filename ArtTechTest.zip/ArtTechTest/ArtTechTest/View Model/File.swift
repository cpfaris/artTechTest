//
//  File.swift
//  ArtTechTest
//
//  Created by Faris on 18/07/23.
//

import Foundation
