//
//  RegisterViewModel.swift
//  ArtTechTest
//
//  Created by Faris on 18/07/23.
//

import Foundation
import UIKit
import CoreData
class RegisterViewModel{
    var delegate: RegisterViewModelDelegate?
    var emailID:Bool?
    var phonenumber:Bool?
    var mobile:String?
    var firstName:String?
    var lastName:String?
    var gender:String?
    var contactno:String?
    var email:String?
    var userName:String?
    var password:String?
    var confirmPassword: String?
    var userCredential : register?
    var context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    func validatePhone(value: String) -> Bool {
        
        let PHONE_REGEX = "^[1-9]\\d{9}$"
        let phoneTest = NSPredicate(format: "SELF MATCHES %@", PHONE_REGEX)
        let result = phoneTest.evaluate(with: value)
        if !result{
            self.delegate?.showError("Please enter a valid mobile number")
        }
        return result
    }
    func userRegisterAct(reg_Value:register){
        if password == confirmPassword{
           
            let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Users")
            let searchString = reg_Value.userName
            request.predicate = NSPredicate (format: "username == %@", searchString ?? "")
            do
            {
                let result = try context.fetch(request)
                if result.count > 0
                {
                    self.delegate?.showError("This user name already exist in our system")
                }
                else{
                    saveCoreData(value: reg_Value)
                }
                
            }
            catch
            {
                print("error")
            }
            
            
        }else{
            self.delegate?.showError("Password and confirm password not matched!")
        }
    }
    func saveCoreData(value : register){
        let _:AppDelegate = (UIApplication.shared.delegate as! AppDelegate)
        let context:NSManagedObjectContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        let newUser = NSEntityDescription.insertNewObject(forEntityName: "Users", into: context) as NSManagedObject
        newUser.setValue(value.userName, forKey: "username")
        newUser.setValue(value.password, forKey: "password")
        do {
            try context.save()
        } catch {}
        print(newUser)
        print("Object Saved.")
        delegate?.registrationCompletion()
        
    }
    
    
    func submitButtonTapped(tag : Int){
        if tag == 1{
            if (firstName == nil)||(firstName == ""){
                self.delegate?.showError("Please enter a valid first name")
                return
            }
        }
        else if tag == 2{
            if (lastName == nil) || (lastName == ""){
                self.delegate?.showError("Please enter a valid last name")
                return
            }
        }
        else if tag == 3{
            if (email == nil) || (email == ""){
                self.delegate?.showError("Please enter a valid email")
                return
            }else if !(email == nil){
                if !(email!.isEmail) {
                    self.delegate?.showError("Please enter a valid email")
                    return
                }}
        }
        else if tag == 4{
            if (mobile == nil) || (mobile == ""){
                self.delegate?.showError("Please enter a valid mobile number")
                return
            }
        }
        else if tag == 5{
            if (userName == nil) || (userName == ""){
                self.delegate?.showError("Please enter a valid username ")
                return
                
            }
        }
        else if tag == 6{
            if (password == nil) || (password == ""){
                self.delegate?.showError("Please enter a valid password ")
                return
            }
        }
        else if tag == 7{
            if (confirmPassword == nil) || (confirmPassword == ""){
                self.delegate?.showError("Please enter a valid password ")
                return
            }else{
                if !(confirmPassword == password){
                    
                    self.delegate?.showError(" Password not matched")
                }
            }
        }
        else{
            if (firstName == nil)||(firstName == "") || (lastName == nil) || (lastName == "") || (email == nil) || (email == "") || (mobile == nil) || (mobile == "") || (userName == nil) || (userName == "") || (password == nil) || (password == "") || (confirmPassword == nil) || (confirmPassword == "") || !(email!.isEmail) || !(validatePhone(value: mobile ?? "")){
                self.delegate?.showError(" Please fill all the fields properly")
            }else{
                if confirmPassword == password{
                    self.delegate?.coreDataRegistration()
                }else{
                    self.delegate?.showError(" Password not matched")
                }
                
            }
        }
    }
}
