//
//  LoginViewController.swift
//  ArtTechTest
//
//  Created by Faris on 18/07/23.
//

import UIKit
import CoreData
//MARK: - @ protocols
protocol LoginViewModelDelegate {
    func showError(_ title:String,_ message: String)
    func loginCompletion(userName : String)
   
}
class LoginViewController: UIViewController {
    //MARK: - @ Outlets
    @IBOutlet weak var txtUserName: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    var context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    var LoginViewModel = loginViewModel()
    override func viewDidLoad() {
        super.viewDidLoad()
        LoginViewModel.delegate = self
        
    }
    @IBAction func btnLoginAct(_ sender: Any) {
        LoginViewModel.userName = self.txtUserName.text
        LoginViewModel.password = self.txtPassword.text
        LoginViewModel.fieldValidation()
     //   LoginViewModel.coreDataLogin(userName: self.txtUserName.text!, password: self.txtPassword.text!)


    }
    @IBAction func btnNewUserAct(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
extension LoginViewController:LoginViewModelDelegate{
    func loginCompletion(userName : String) {
       // DispatchQueue.main.async {
            let alertController = UIAlertController(title: "Login", message: "Successfully login with user name : \(userName) ", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (actin) in
                alertController.dismiss(animated: true, completion: nil)
                
                let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "HomeViewController") as? HomeViewController
                vc?.userName = userName
                self.navigationController?.pushViewController(vc!, animated: true)
             
            }))
            
            self.present(alertController, animated: true, completion: nil)
      //  }
    }
    func showError(_ title:String ,_ message: String) {
        DispatchQueue.main.async {
            let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "Ok", style: .default))
            
            self.present(alertController, animated: true, completion: nil)
        }
    }
}
