//
//  HomeViewController.swift
//  ArtTechTest
//
//  Created by Faris on 19/07/23.
//

import UIKit

class HomeViewController: UIViewController {
    @IBOutlet weak var lblWelcome: UILabel!
    var userName : String?
    override func viewDidLoad() {
        super.viewDidLoad()
        lblWelcome.text = "Welcome username : \(userName ?? "")"
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
