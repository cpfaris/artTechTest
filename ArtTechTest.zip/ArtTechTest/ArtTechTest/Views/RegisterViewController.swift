//
//  RegisterViewController.swift
//  ArtTechTest
//
//  Created by Faris on 18/07/23.
//

import UIKit
import CoreData
//MARK: - @ protocols

protocol RegisterViewModelDelegate {
    func registrationCompletion()
    func coreDataRegistration()
    func showError(_ message: String)
    func navigateToHomeViewController(_ homeViewController: UIViewController)
}
class RegisterViewController: UIViewController,UITextFieldDelegate {
    //MARK: - @ Outlets
    @IBOutlet weak var txtFirstName: UITextField!
    @IBOutlet weak var txtLastName: UITextField!
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtMobile: UITextField!
    @IBOutlet weak var txtUserName: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    @IBOutlet weak var txtConfirmPassword: UITextField!
    @IBOutlet weak var btnFemail: UIButton!
    @IBOutlet weak var btnMale: UIButton!
    
    var registerViewModel = RegisterViewModel()
    var reg : register?
    var isChecked = true
    override func viewDidLoad() {
        super.viewDidLoad()
       
        setUpDelegates()
        setUpUI()
       
    }
    func setUpUI(){
        btnMale.setImage(UIImage(named: "Selected"), for: .normal)
        btnFemail.setImage(UIImage(named: "UnSelected"), for: .normal)
        btnMale.layer.cornerRadius = 12
        btnMale.layer.masksToBounds = true
        btnMale.layer.borderWidth = 1
        btnMale.layer.borderColor = UIColor.gray.cgColor
        
        btnFemail.layer.cornerRadius = 12
        btnFemail.layer.masksToBounds = true
        btnFemail.layer.borderWidth = 1
        btnFemail.layer.borderColor = UIColor.gray.cgColor
    }
    func setUpDelegates(){
        registerViewModel.delegate = self
        txtFirstName.delegate = self
        txtLastName.delegate = self
        txtEmail.delegate = self
        txtMobile.delegate = self
        txtUserName.delegate = self
        txtPassword.delegate = self
        txtConfirmPassword.delegate = self
    }
    
    @IBAction func btnMaleAct(_ sender: Any) {
        btnMale.setImage(UIImage(named: "Selected"), for: .normal)
        btnFemail.setImage(UIImage(named: "UnSelected"), for: .normal)
    }
    @IBAction func btnFemailAct(_ sender: Any) {
        btnFemail.setImage(UIImage(named: "Selected"), for: .normal)
        btnMale.setImage(UIImage(named: "UnSelected"), for: .normal)
    }
    @IBAction func btnRegisterAct(_ sender: Any) {
        
        registerViewModel.submitButtonTapped(tag: 0)
        
    }
    
    @IBAction func btnLoginAct(_ sender: Any) {
        let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "LoginViewController") as? LoginViewController
        self.navigationController?.pushViewController(vc!, animated: true)
    }
    
    func textFieldShouldReturn(_ textField: UITextField!) -> Bool {
        self.view.endEditing(true)
        return true
    }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if textField == txtMobile{
            let maxLength = 10
            let currentString :NSString = textField.text! as NSString
            let newString: NSString = currentString.replacingCharacters(in: range, with: string) as NSString
            return newString.length <= maxLength
        }
        return true
    }
    func textFieldDidEndEditing(_ textField: UITextField, reason: UITextField.DidEndEditingReason) {
        
        if textField == txtFirstName{
            
            registerViewModel.firstName =  txtFirstName.text
            //            registerViewModel.isEmpty()
            registerViewModel.submitButtonTapped(tag: 1)
            return
        }
        else if textField == txtLastName{
            
            registerViewModel.lastName =  txtLastName.text
            registerViewModel.submitButtonTapped(tag: 2)
            return
        }
        
        else if textField == txtEmail{
            
            registerViewModel.email =  txtEmail.text
            registerViewModel.submitButtonTapped(tag: 3)
            return
        }
        else if textField == txtMobile{
            
            registerViewModel.mobile =  txtMobile.text
            registerViewModel.validatePhone(value: txtMobile.text ?? "0")
            return
        }
        else if textField == txtUserName{
            
            registerViewModel.userName =  txtUserName.text
            registerViewModel.submitButtonTapped(tag: 5)
            return
        }
        else if textField == txtPassword{
            
            registerViewModel.password =  txtPassword.text
            registerViewModel.submitButtonTapped(tag: 6)
            return
        }
        else if textField == txtConfirmPassword{
            
            registerViewModel.confirmPassword =  txtConfirmPassword.text
            registerViewModel.submitButtonTapped(tag: 7)
            return
        }
        
        /*
         // MARK: - Navigation
         
         // In a storyboard-based application, you will often want to do a little preparation before navigation
         override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
         // Get the new view controller using segue.destination.
         // Pass the selected object to the new view controller.
         }
         */
        
    }
}
//MARK: - @ RegisterViewModel Delegate Methods

extension RegisterViewController : RegisterViewModelDelegate{
    func registrationCompletion() {
        // DispatchQueue.main.async {
        let alertController = UIAlertController(title: "Register", message: "Registration successfully completed", preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (actin) in
            alertController.dismiss(animated: true, completion: nil)
            
            let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "LoginViewController") as? LoginViewController
            self.navigationController?.pushViewController(vc!, animated: true)
            
        }))
        
        self.present(alertController, animated: true, completion: nil)
      
    }
    func myHandler(alert: UIAlertAction){
        print("You tapped: \(alert.title)")
    }
    func coreDataRegistration(){
        let regValues = register(userName: txtUserName.text, password: txtPassword.text)
        registerViewModel.userRegisterAct(reg_Value: regValues)
    }
    func navigateToHomeViewController(_ homeViewController: UIViewController) {
        
        let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "LoginViewController") as? LoginViewController
        self.navigationController?.pushViewController(vc!, animated: true)
    }
    
    func showError(_ message: String) {
        DispatchQueue.main.async {
            let alertController = UIAlertController(title: "Register", message: message, preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "Ok", style: .default))
            
            self.present(alertController, animated: true, completion: nil)
        }
    }
}
